# Sample Project — Roadmap

## ✅ Déjà livré

| # | Feature | Endpoint(s) / Composant(s) |
|---|---|---|
| 1 | **Login flow** | `src/auth/login.ts` |
| 2 | **DB schema** | `src/db/schema.ts` |

## 🎯 Tier 1

### 1.1 — Migration runner ✅
**Promesse** : runner pour appliquer les migrations.

**Premier pas** : `src/db/orphan.py` placeholder.

### 1.2 — Helpers utility ⏳
**Expected by** : 2026-Q2

**Promesse** : fonctions partagées.

**Premier pas** : `src/utils/helpers.ts` exports an `id` function.

### 1.3 — Config validator ⏳
**Expected by** : 2026-Q3

**Promesse** : valide `gitnexus-domains.json` au chargement.

**Premier pas** : `gitnexus-domains.json` existe déjà, non validé.

### 2.1 — Audit log 🗑️
**Promesse** : journal d'audit.

**Premier pas** : cancelled, not implementing.

### 2.2 — Cancelled feature 🗑️
**Promesse** : another feature we never shipped.

**Premier pas** : cancelled, kept here to exercise audit cancellation-rate.

## 🔗 Clusters

### Tier 1 foundation
**ExpectedBy** : 2026-Q3
**Members** : tier-1-2-helpers-utility, tier-1-3-config-validator
