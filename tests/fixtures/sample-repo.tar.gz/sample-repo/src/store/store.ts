export interface Cache {
  get(k: string): string;
}

export class Store {
  read(): string { return ""; }
}

export class UserStore extends Store {
  find(id: string): string { return id; }
}

export class MemoryCache extends Store implements Cache {
  get(k: string): string { return k; }
}
