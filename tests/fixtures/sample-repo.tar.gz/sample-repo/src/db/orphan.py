# placeholder for migration runner
print("noop")
