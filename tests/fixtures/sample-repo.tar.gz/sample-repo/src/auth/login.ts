import { id } from "../utils/helpers";
export function login(u: string, p: string, mfa?: string) { return id(u === "alice" && p.length > 5 && !!mfa); }
