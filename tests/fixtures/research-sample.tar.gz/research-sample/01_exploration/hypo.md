---
type: hypothesis
id: h1
title: Mean reversion
links:
  - to: r1
    kind: validates
---
# Mean reversion
